﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TNCAX25Emulator
{
    public partial class PopUpcallsign : Form
    
    {
        Object reference;
        public PopUpcallsign(Object reference)
        {
            this.reference=reference; 
            InitializeComponent();
        }

        private void callsign_TextChanged(object sender, EventArgs e)
        {

        }

        private void path_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Check the parameters. If they are ok, then allow. If not display an error dialog.
            if ((validdatecallsign(callsign.Text))&&(validdatecallsign(path.Text)))
            {
                Usersetting.callsign = callsign.Text;
                Usersetting.path = path.Text;
                this.Close();
            }else
            
             MessageBox.Show("Error in path or callsign please correct", "TNCAX25Emulator",
             MessageBoxButtons.OK, MessageBoxIcon.Error);
           
        }
        private Boolean validdatecallsign(String tBxcallsign)
        {
            Boolean valid = true;
            try
            {
                int SSID = 0;

                {
                    if (tBxcallsign.Length <= 9)
                    {
                        string[] callsignandSSID = tBxcallsign.Split('-');
                        if (callsignandSSID.Length > 1)
                        {

                            char[] ssid = callsignandSSID[1].ToArray();
                            if (ssid.Length < 3)
                            {
                                if (ssid.Length > 1)
                                {
                                    string ascii = "" + ssid[1];
                                    int SSIDno = Convert.ToInt32(ascii, 10);
                                    ascii = "" + ssid[0];
                                    int SSIDxten = Convert.ToInt32(ascii, 10) * 10;
                                    SSID = SSIDxten + SSIDno;
                                    if (SSID > 15)
                                    {
                                        valid = false;
                                    }
                                }
                                else
                                {
                                    string ascii = "" + ssid[0];
                                    SSID = Convert.ToInt32(ascii, 10);
                                }
                            }
                            else
                            {
                                valid = false;

                            }
                        }
                        if ((callsignandSSID[0].Length < 7) & (SSID < 16))
                        {
                            valid = true;
                        }
                        else
                        {
                            valid = false;
                        }
                        //  
                    }
                    else
                    {
                        valid = false;
                    }

                }
            }
            catch (Exception e)
            {
                valid = false;
            }
            return valid;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            path.Text = Usersetting.path;
            callsign.Text = Usersetting.callsign;
            this.Close();
        }

        private void PopUpcallsign_Load(object sender, EventArgs e)
        {

        }

    }
}
