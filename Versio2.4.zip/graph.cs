﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Threading;

namespace TNCAX25Emulator
{
    class graph
    {
        private PictureBox pb;
        private static System.Windows.Forms.Timer timer;
        Point[] points;
      
        int y,y1,oldy;
        int max = 0xFFFFFFF;
        int xAxisPos; // x axis at bottom of plot
        int yScale;
        int xScale;
        float binSize;
        int binlow;
        int binhigh;
        int xstep;
        int mousePTR = 0;
        int mousePTRclick = 0;
        int bwoffset = 0;
        
        
        BufferedGraphicsContext currentContext;
        BufferedGraphics myBuffer;
        private static ReaderWriterLockSlim _lock = new ReaderWriterLockSlim();
        Pen greenPen = new Pen(Color.SpringGreen, 4);
        SolidBrush myBrush = new System.Drawing.SolidBrush(System.Drawing.Color.Blue);
        SolidBrush myRedBrush = new System.Drawing.SolidBrush(System.Drawing.Color.Red);
        SolidBrush yellowBrush = new SolidBrush(Color.Yellow);
        StringFormat drawFormat = new StringFormat();
        StringFormat drawFormat1 = new StringFormat();
        Font myFont = new Font("Arial", 10);
        Boolean state = true;
     
        int rmspower=0;
        int peakholdcnt = 0;

        public graph(PictureBox pb)
        {
            this.pb = pb;
            xScale = (int)(((Config.FFTRES / 2) + 1 )/ pb.Width);
             binSize = (float) Config.samplingrate / (float) Config.FFTRES;
            binlow = (int)( 1000 / binSize);
            binhigh = (int)(2000 / binSize);
            xstep =  pb.Width/(binhigh - binlow);
            yScale = (int)max / pb.Height;
            xAxisPos = pb.Height-5;//-5
            rmspower = pb.Height;
            points = new Point[pb.Width-30];//Todo make this dependant on calculating the audio buffer.
            
            
            timer = new System.Windows.Forms.Timer();
            timer.Interval = 5;//5
            timer.Tick += new EventHandler(timer_Tick);
            timer.Start();

        
            currentContext = BufferedGraphicsManager.Current;
            drawFormat.FormatFlags = StringFormatFlags.DirectionVertical;
            drawFormat1.FormatFlags = StringFormatFlags.NoWrap;
            myBuffer = currentContext.Allocate(pb.CreateGraphics(),
                new Rectangle(0, 0, Math.Max(pb.Width, 1), Math.Max(pb.Height, 1)));
            myBuffer = currentContext.Allocate(pb.CreateGraphics(),
               pb.DisplayRectangle);

                                 
        }
        public void Halt()
        {
            timer.Stop();
            state = false;
            
        }
        public void start()
        {
            state = true;
            timer.Start();
        }

       public void setscreenPTR(int mousePTR){
           if (mousePTR != -1)
           {
               int freqofmouseptr = (int)(mousePTR   * 23.47/2) + 1000;
               if ((freqofmouseptr <= (1000 + Usersetting.offset))||( (freqofmouseptr >= (2652+1000))))return ;
           }
           else
           {
               mousePTR = 0;
           }
           this.mousePTR = mousePTR;
           
       }

       public Boolean setscreenPTRconform(int mousePTR)
       {
           int freqofmouseptr = (int)(mousePTR * 23.47 / 2) + 1000;
           if ((freqofmouseptr <= (1000 + Usersetting.offset)) || ((freqofmouseptr >= (2652 + 1000)))) return false;
           this.mousePTRclick = mousePTR;
           return true;
          
       }
       public void setScreenFreq(int freq)
       {
           int factor = (int)((float)((freq / (23.47 / 2))) - 86);
           this.mousePTRclick = factor;
       }
       public void filterBW(int bwoffset)
       {
           
           this.bwoffset = (int)((float)bwoffset*((float)(Config.FFTRES/2)/((float)pb.Width)));
       }
       public void clear(string toDisplay)
       {
           _lock.EnterReadLock();
           myBuffer.Graphics.Clear(Color.Black);
           _lock.ExitReadLock();
       }


       public void storePointstoPlot(float[] values, float power, float filtercentre)
       {
           try
           {
               if (float.IsNaN(power)) return;
               if (state == true)
               {
               _lock.EnterReadLock();
              
                   myBuffer.Graphics.Clear(Color.Black);
                   int x = 0;
                   for (int i = 0; i < pb.Width - 30; )
                   {
                       y = xAxisPos - (int)(values[binlow + x] / yScale);
                       y1 = (int)(oldy + y) / 2;
                       if (y >= 160) y = 160;
                       if (y1 >= 160) y1 = 160;
                       oldy = y1;
                       Point point1 = new Point(i, y);
                       points[i++] = point1;


                       point1 = new Point(i, y1);
                       points[i++] = point1;


                       /*  point1 = new Point(i, y);
                         points[i++] = point1;

                         point1 = new Point(i, y);
                         points[i++] = point1;*/
                       x++;
                   }
                   int powscale = (int)((float)(((power / 9000000))) * 80);
                   powscale = 160 - powscale;
                   //   rmspower = 0;
                   if (powscale <= 0) powscale = 0;

                   {
                       peakholdcnt++;
                       if (rmspower >= powscale)
                       {
                           rmspower = powscale;
                           peakholdcnt = 0;
                       }
                       else
                       {
                           if (peakholdcnt > 25)
                           {
                               rmspower = powscale;
                               peakholdcnt = 0;
                           }
                       }
                   }

                   int factor = (int)((float)((filtercentre) / (23.47 / 2))) - 86;
                   myBuffer.Graphics.DrawString("Trk " + filtercentre.ToString() + "Hz", myFont, yellowBrush, new Point(factor, 30), drawFormat);
                   myBuffer.Graphics.DrawLine(Pens.Cyan, factor, 0,
                                factor, pb.Height - 5);//998.
                   myBuffer.Graphics.DrawLine(Pens.Yellow, mousePTR, 0,
                              mousePTR, pb.Height - 5);
                   myBuffer.Graphics.DrawLine(Pens.Yellow, mousePTR - bwoffset, 0,
                              mousePTR - bwoffset, pb.Height - 5);
                   myBuffer.Graphics.DrawLine(Pens.Red, mousePTRclick, 0,
                              mousePTRclick, pb.Height - 5);
                   myBuffer.Graphics.DrawLine(Pens.Red, mousePTRclick - bwoffset, 0,
                             mousePTRclick - bwoffset, pb.Height - 5);
                   //myBuffer.Graphics.FillEllipse(myBrush, 180, 6, 5, 5);
                   myBuffer.Graphics.FillRectangle(myRedBrush, new Rectangle(pb.Width - 20, rmspower, 10, pb.Width - 35));
                   myBuffer.Graphics.DrawLines(greenPen, points);
                   _lock.ExitReadLock();
               }
           }
           catch (Exception e)
           {

               MessageBox.Show("Graph "+e.ToString(), "TNCAX25Emulator",
                     MessageBoxButtons.OK, MessageBoxIcon.Error);
           }
       
       }


        private void timer_Tick(object sender, EventArgs e) {
            try{
            _lock.EnterWriteLock();
             myBuffer.Render(pb.CreateGraphics());
            _lock.ExitWriteLock();
            }catch(Exception er) {}
          
        }   
      
    }
}
