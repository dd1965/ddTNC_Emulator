﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;

namespace TNCAX25Emulator
{
    class Logging
    {
        static string mydirectory;
        static String day;
        private static ReaderWriterLockSlim _lock = new ReaderWriterLockSlim();
        public Logging()
        {
            mydirectory = Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData);
          
            String AppName = System.Reflection.Assembly.GetEntryAssembly().GetName().Name;
            mydirectory = mydirectory + "\\" + AppName;
            Directory.CreateDirectory(mydirectory);                   
        }
        public static void logData(String data)
        {
            day = DateTime.Now.ToString("dMMyyyy");
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(mydirectory + "\\Log_" + day + ".txt", true))
            {
                
                _lock.EnterWriteLock();
                 file.WriteLine(data);
                _lock.ExitWriteLock();
            }
        }
    }
}
