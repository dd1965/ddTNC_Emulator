﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WinMM;

namespace TNCAX25Emulator
{
    class Hdlc
        
    {
        private const int tone_2200 = 1;
        private const int tone_1200 = 0;
        int lasttoneport1 = tone_1200;
        int bitstuff = 0;
        private const int tone_1600 = 1;
        private const int tone_1800 = 0;
        int lasttoneport2 = tone_1600;
        int bitstuff2 = 0;
        private const byte FLAG = 0x7E;
        private const byte FLAGSIZE = 20;
        private const byte ENDFLAGSIZE = 1;
        private GenerateTone gt;
        public void senddata(byte[] txdatabuf,GenerateTone  gt)
        {
           this.gt = gt;
           ushort crc;
           
          // byte[] buffer = new byte[15] { 0x90, 0x84, 0x72, 0xb4, 0xa4, 0x90, 0x60, 0x90, 0x84, 0x72, 0xa0, 0xaa, 0x9e, 0xe1, 0xf1 };
           /*  buffer byte $90, $84, $72, $b4, $a4, $90,$60, $90, $84, $72, $a0, $aa, $9e, $e1, $f1, 0, 0 'checksum $30 $26 test frames*/


           
           crc = CRC16(txdatabuf);
           byte[] crclohi = new byte[2];
           crclohi[0] = (byte)(crc & 0xFF);
           crclohi[1] = (byte)((crc >> 8) & 0xFF);

           byte[] ax25FrametoSend = new byte[txdatabuf.Length+2];
           sendFrameport1(addflag(),true);
           Array.Copy(txdatabuf, 0, ax25FrametoSend, 0, txdatabuf.Length);
           Array.Copy(crclohi, 0, ax25FrametoSend,txdatabuf.Length, crclohi.Length);
           sendFrameport1(ax25FrametoSend, false);
           byte[] endfl = new byte[1] { FLAG };
           sendFrameport1(endfl,true);
           
           sendFrameport2(addflag(), true);
           sendFrameport2(ax25FrametoSend, false);
           sendFrameport2(endfl, true);
        
        }
        private byte[] addflag(){
            byte[] flagbuf = new byte[FLAGSIZE];
            for (int i = 0; i < FLAGSIZE; i++)
            {
                flagbuf[i] = FLAG;
            }
            return flagbuf;
        }

        
        private ushort CRC16(byte[] bytes)
        {
           /* This was a pain in the arse. Not documented at all! */
           /* This is what is used for AX25                      */
            ushort crc = 0xFFFF; //(ushort.maxvalue, 65535)

            for (int j = 0; j < bytes.Length; j++)
            {
                crc = (ushort)(crc ^ bytes[j]);
                for (int i = 0; i < 8; i++)
                {
                    if ((crc & 0x0001) == 1)
                        crc = (ushort)((crc >> 1) ^ 0x8408);
                    else
                        crc >>= 1;
                }
            }
            return (ushort)~(uint)crc;    //A neat way to invert a byte.
        }

        private void sendFrameport1(byte[] ax25frame, Boolean flag)
        {
            byte inbyte;
            for (int i = 0; i < ax25frame.Length; i++)
            {
                inbyte = ax25frame[i];
                // Inner loop.

                int k, bt;
                for (k = 0; k < 8; k++)
                {                                               //do the following for each of the 8 bits in the byte
                    bt = inbyte & 0x01;                           //strip off the rightmost bit of the byte to be sent (inbyte)

                    if (bt == 0)
                    {
                        nrziport1();                                 // if this bit is a zero, flip the output state
                    }
                    else
                    {                                            //otherwise if it is a 1, do the following:
                        bitstuff++;                             //increment the count of consecutive 1's 
                        if ((flag == false) && (bitstuff == 5))
                        {   	                                //stuff an extra 0, if 5 1's in a row
                            gt.sendAX25tone1200BAUD(lasttoneport1);  //send 1/1200t of tone 833.3us
                            nrziport1();            		           //flip the output state to stuff a 0
                        }
                    }
                    inbyte = (byte)(inbyte >> 1);          		   //go to the next bit in the byte
                    gt.sendAX25tone1200BAUD(lasttoneport1);			   //send 1/1200t of tone 833.3us
                }
            }
        }

        private void nrziport1()
        {
            bitstuff = 0;
            if (lasttoneport1 == tone_1200)
            {
                lasttoneport1 = tone_2200;
            }
            else
            {
                lasttoneport1 = tone_1200;
            }
            return;
        }

        private void sendFrameport2(byte[] ax25frame, Boolean flag)
        {
            byte inbyte;
            for (int i = 0; i < ax25frame.Length; i++)
            {
                inbyte = ax25frame[i];
                // Inner loop.

                int k, bt;
                for (k = 0; k < 8; k++)
                {                                               //do the following for each of the 8 bits in the byte
                    bt = inbyte & 0x01;                           //strip off the rightmost bit of the byte to be sent (inbyte)

                    if (bt == 0)
                    {
                        nrziport2();                                 // if this bit is a zero, flip the output state
                    }
                    else
                    {                                            //otherwise if it is a 1, do the following:
                        bitstuff2++;                             //increment the count of consecutive 1's 
                        if ((flag == false) && (bitstuff2 == 5))
                        {   	                                //stuff an extra 0, if 5 1's in a row
                            gt.sendAX25tone300BAUD(lasttoneport2);  //send 1/1200t of tone 833.3us
                            nrziport2();            		           //flip the output state to stuff a 0
                        }
                    }
                    inbyte = (byte)(inbyte >> 1);          		   //go to the next bit in the byte
                    gt.sendAX25tone300BAUD(lasttoneport2);			   //send 1/1200t of tone 833.3us
                }
            }
        }

        private void nrziport2()
        {
            bitstuff2 = 0;
            if (lasttoneport2 == tone_1600)
            {
                lasttoneport2 = tone_1800;
            }
            else
            {
                lasttoneport2 = tone_1600;
            }
            return;
        }

        public static bool IsOn(byte Value, byte Bit)
        { return (Value >> Bit & 1) == 1; }

        internal static class Bit
        {
            /// <summary>
            /// Verifica se un bit è 1 in un valore.
            /// </summary>
            /// <param name="Value">Valore oggetto della verifica.</param>
            /// <param name="Bit">Posizione del bit.</param>
            /// <returns>True se il bit è 1, false se è 0.</returns>
            public static bool IsOn(int Value, byte Bit)
            { return (Value >> Bit & 1) == 1; }

            /// <summary>
            /// Imposta ad 1 un bit in un valore.
            /// </summary>
            /// <param name="Value">Valore in cui impostare il bit.</param>
            /// <param name="Bit">Posizione del bit.</param>
            /// <returns>Il nuovo valore.</returns>
            public static int Set(int Value, byte Bit)
            { return Set(Value, Bit, true); }

            /// <summary>
            /// Varia un bit in un valore.
            /// </summary>
            /// <param name="Value">Valore in cui variare il bit.</param>
            /// <param name="Bit">Posizione del bit.</param>
            /// <param name="On">Se True imposta il bit ad 1, se False lo imposta a 0.</param>
            /// <returns>Il nuovo valore.</returns>
            public static int Set(int Value, byte Bit, bool On)
            { return On ? Value | (1 << Bit) : Clear(Value, Bit); }

            /// <summary>
            /// Imposta ad 0 un bit in un valore.
            /// </summary>
            /// <param name="Value">Valore in cui impostare il bit.</param>
            /// <param name="Bit">Posizione del bit.</param>
            /// <returns>Il nuovo valore.</returns>
            public static int Clear(int Value, byte Bit)
            { return Value & ~(1 << Bit); }
        }


    }
}
