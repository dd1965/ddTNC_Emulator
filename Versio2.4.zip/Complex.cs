﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TNCAX25Emulator
{
    public struct Complex
    {
        public double r;
        public double i;

        public Complex(double real, double imaginary)  //constructor
        {
            this.r = real;
            this.i = imaginary;
        }

        // Declare which operator to overload (+),
        // the types that can be added (two Complex objects),
        // and the return type (Complex):
        public static Complex operator +(Complex c1, Complex c2)
        {
            return new Complex(c1.r + c2.r, c1.i + c2.i);
        }

        // Override the ToString() method to display a complex number in the traditional format:
        public override string ToString()
        {
            return (System.String.Format("{0} + {1}i", r, i));
        }
    }
}

