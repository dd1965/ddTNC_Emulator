﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace TNCAX25Emulator
{
    class GPS
    {
        Boolean validframe = false;
        Queue GPSreceiveddataQueue = new Queue();
        public  Boolean processGPSframe(byte[] GPSframe)
        {
           
            int checksum = 0;
            for (int i = 1; i < GPSframe.Length; i++)//was zero
            {
                if (GPSframe[i] == 0x2A)
                {
                    int decchksum = 0;
                    int value; 
                    char receivedchecksumlsb = (char) GPSframe[GPSframe.Length-1];
                    string hexascii = ""+ receivedchecksumlsb;
                    decchksum = Convert.ToInt32(hexascii, 16);
                    char receivedchecksummsb = (char)GPSframe[GPSframe.Length - 2];
                    hexascii = ""+ receivedchecksummsb;
                    value  = Convert.ToInt32(hexascii, 16);
                    decchksum = (value * 16) + decchksum;
                  
                    
                    if (checksum != decchksum) 
                    {
                        validframe = false;
                         //Silently discard
                         //Test frame
                        //$GPGGA,092750.000,5321.6802,N,00630.3372,W,1,8,1.03,61.7,M,55.2,M,,*76
                    }
                    else
                    {
                        validframe = true;
                        //Enque Here Copy a new frame across with the correct data ie *and checksum removed.TBC
                    }
                    break;
                }
                else
                {
                    checksum ^= GPSframe[i];
                }

            }
          return validframe;
        } 
     }
}
