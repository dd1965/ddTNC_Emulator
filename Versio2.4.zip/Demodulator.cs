﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.Concurrent;

namespace TNCAX25Emulator
{
    class Demodulator
    {
        static short[] data = new short[Config.bufferisizeforCorrelatortone];
        static short[] coeffloi = new short[Config.bufferisizeforCorrelatortone]; /* Coefficient: cos 1200 Hz */
        static short[] coeffloq = new short[Config.bufferisizeforCorrelatortone]; /* Coefficient: sin 1200 Hz */
        static short[] coeffhii = new short[Config.bufferisizeforCorrelatortone]; /* Coefficientn: cos 2200 Hz */
        static short[] coeffhiq = new short[Config.bufferisizeforCorrelatortone]; /* Coefficient: sin 2200 Hz */
        static short ptr = 0;
        int N = Config.bufferisizeforCorrelatortone;
        ConcurrentQueue<byte> correlatorQueue = new ConcurrentQueue<byte>();
        ConcurrentQueue<float[]> correlatorQueue1 = new ConcurrentQueue<float[]>();
        ConcurrentQueue<int> timerpointer = new ConcurrentQueue<int>();
        Movingaveragefilter mvAvgFilt;
        Boolean reverse = false;
        int symbol = Config.SYMBOL;         
        object reference;     

        public Demodulator(object reference){
            this.reference = reference;
            mvAvgFilt = new Movingaveragefilter(symbol/2);
            
            double thetahi = 2.0f * (float)Math.PI * (Config.MARK) / Config.samplingrate;
            double thetalo = 2.0f * (float)Math.PI * (Config.MARK-Config.OFFSET) / Config.samplingrate;

          
           
           
            for (int i = 0; i < N ; i++)
            {
                coeffloi[i] = (short)((Math.Cos(i * thetalo)) * 32767);
                coeffloq[i] = (short)((Math.Sin(i * thetalo)) * 32767);
                coeffhii[i] = (short)((Math.Cos(i * thetahi)) * 32767);
                coeffhiq[i] = (short)((Math.Sin(i * thetahi)) * 32767);
            }
         
        }
        public void changefreq(int fhi,int flo)
        {
           

            double thetahi = 2.0f * (float)Math.PI * fhi / Config.samplingrate;
            double thetalo = 2.0f * (float)Math.PI * flo / Config.samplingrate;


            //The rest is padded with zeros?

            for (int i = 0; i < N; i++)
            {
                coeffloi[i] = (short)((Math.Cos(i * thetalo)) * 32767);
                coeffloq[i] = (short)((Math.Sin(i * thetalo)) * 32767);
                coeffhii[i] = (short)((Math.Cos(i * thetahi)) * 32767);
                coeffhiq[i] = (short)((Math.Sin(i * thetahi)) * 32767);
            }
           // phaseFilter = new decimator(phasefilterCoeff, phasefilterCoeff.Length, 1);
        }
        public float demodulate(float input) {

          //   input= mvAvgFilt1.runFilt(input);
            short d;
            double outloi=0,outloq=0,outhii=0,outhiq=0;
            data[ptr]=(short)input; ptr = (short)((ptr+1)%N); /* % : Modulo */
            for(int i=0;i<N;i++) {
                d = data[(ptr+i)%N];
               outloi += d*coeffloi[i];
               outloq += d*coeffloq[i];
               outhii += d*coeffhii[i];
               outhiq += d*coeffhiq[i];
               
             }
           
          float output;
          if(!reverse)
          output =(float )(((outhii / 5120000 * outhii / 5120000) + (outhiq / 5120000 * outhiq / 5120000)) - ((outloi / 5120000) * (outloi / 5120000) + (outloq / 5120000) * (outloq / 5120000)));
          else output = (float)(((outloi / 5120000) * (outloi / 5120000) + (outloq / 5120000) * (outloq / 5120000))-((outhii / 5120000 * outhii / 5120000) + (outhiq / 5120000 * outhiq / 5120000)));//REV

          output = mvAvgFilt.runFilt(output);
            // if (Math.Abs(output) < 100) output = 0;
            return output;
       }
        public float demodulate1(float input)
        {
            float output = mvAvgFilt.runFilt(input);
            return output;
        }

        public void changeBaud(int baud)
        {
            this.symbol = Config.samplingrate / baud;
            mvAvgFilt = new Movingaveragefilter(symbol / 2);
        }
        public void changeReverse(Boolean rev)
        {
            this.reverse = rev;
        }
    }
}
