﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TNCAX25Emulator
{
    class Kiss
    {
        public byte[] decodeKissFrame(byte[] rxTNC)
        {   //TODO
            return (null);
        }

        public byte[] encodeKissFrame(byte[] txTNC)
        {
            int offset = 2;
            int index  = offset;
            byte[] newbuffertosend = new byte[txTNC.Length*2+3]; //Hopefully we dont run out of space...
            newbuffertosend[0] = 0xC0; //Start the frame
            newbuffertosend[1] = 0x00; //Data frame

            for (int i = 0; i < txTNC.Length; i++) 
            {
                if (txTNC[i] == 0xC0)
                {
                    newbuffertosend[index++] = 0xDB;//FESC
                    newbuffertosend[index++] = 0xDC;//TFEND
                    break;
                }
                else if (txTNC[i] == 0xDB)
                {
                    newbuffertosend[index++] = 0xDB;//FESC
                    newbuffertosend[index++] = 0xDD;//TFESC
                    break;
                }
                else
                {
                    newbuffertosend[index++] = txTNC[i];
                }
                   
            }

            newbuffertosend[index++]=0xC0;
            byte[] newbuffertosendcorrectlength = new byte[index];
            Array.Copy(newbuffertosend, newbuffertosendcorrectlength, newbuffertosendcorrectlength.Length);
            return newbuffertosendcorrectlength;

        }
    }
}
