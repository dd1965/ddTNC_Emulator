﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WinMM;

namespace TNCAX25Emulator
{
    public static class Config
    {
        /* Sound card settings */
       // private static Config instance;
        public static WaveFormat waveformat =  WaveFormat.Pcm24Khz16BitStereo;
        public static int samplingrate = waveformat.SamplesPerSecond;        //Samples per second
        public static short channels = waveformat.Channels;              //1-Mono 2-Stereo
        public static short bits = waveformat.BitsPerSample;
  
        /*FIR Filter Definitions */
        public static int decimationrate = 4;
        public static int interpolationrate = 4;

        /*Centre frequency fc. Used for testing*/
        public static int fc = 12000; //This sets the IF frequency

        /* Number of fourier taps */
        public static int FFTRES = 1024;                  //must be 2 raised to the power of N

        /* Number of samples for 1ms */
        public static double numberofsamplesfor1ms = (Config.samplingrate * 0.001);

       /* Compute number of samples for 1200 baud. Use 24Khz as sampling rate*/
       /* Buffer size is a nice round value 20 */
        public static int bufferisizefor1200baudtone =  Config.samplingrate/1200;
        public static int bufferisizefor300baudtone = Config.samplingrate / 300;

        public static int bufferisizeforCorrelatortone = Config.samplingrate / 1000;
        public static int baudrate = 100;
        public static int SYMBOL = Config.samplingrate / baudrate;
        public static int MARK = 1500;
        public static int OFFSET = 500;
        public static int OFFETFROMCENTRE = OFFSET / 2;
        
        public static int SIGNAL = 1;
        public static int SPECTRUM = 2;




    
    }
}


