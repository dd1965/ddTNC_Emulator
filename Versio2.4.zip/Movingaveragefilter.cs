﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TNCAX25Emulator
{
    
    class Movingaveragefilter
    {
        int len;
        int pint = 0;
        Boolean empty;
        float[] input;
        float output;

       public  Movingaveragefilter(int filtlen){
    
	      len = filtlen;
	      input = new float[len];
	      empty = true;
        }


       public float runFilt(float a){
	    if (empty) 
         {
		    empty = false;
		    for (int i = 0; i < len; i++)
            {
			input[i] = a;
		    }
		    output = a * len;
		   pint = 0;
		   return a;
        }
	    
	    output = output - input[pint] + a;
	    input[pint] = a;
	    if (++pint >= len) pint = 0;
	    return (output / len);
        }
    }
}
