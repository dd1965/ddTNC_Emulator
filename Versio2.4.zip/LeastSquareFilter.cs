﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TNCAX25Emulator
{
    class LeastSquareFilter
    {
        float k0, k1, k2, k3,k4,k5,k6,k7 = 0;
        double y = 0;
        public float runFilt4(float input)
        {
            k0 = input;
            y = 0.41667 * k0+0.3333*k1+0.25*k2-0.16667*k3+0.08333*k4+0*k5-0.08333*k6-0.16667*k7;
            k7 = k6;
            k6 = k5;
            k5 = k4;
            k4 = k3;
            k3 = k2;
            k2 = k1;
            k1 = k0;
            return (float)y;
        }
       

    }
}
