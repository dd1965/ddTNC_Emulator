﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TNCAX25Emulator
{
   public static class Receivedparameters
    {
       
       public static string altiude{get;set;}
       public static string speed { get; set; }
       public static string lat { get; set; }
       public static string longitude { get; set; }
       public static string tin { get; set; }
       public static string tout { get; set; }
       public static string sequence{ get; set; }
       public static string satno { get; set; }
       public static string veld { get; set; }
       public static string volts { get; set; }
       public static string gpsfix { get; set; }
       public static string time { get; set; }
       public static string debug { get; set; }
       public static string psbcallsign { get; set; }
       //count, hour:minute:second, lat_str, lon_str, alt, gspeed, veld, sats, lock, Temp_in,Temp_out,Vbatt,debug*CHECKSUM
       //$$PSB,599,07:17:53,-36.2431,143.1503,431,5.12,-2.14,9,3,34,31,3032,_*BBD7
       public static string payload()
       {
           return (sequence + " " + time + " " + lat + " " + longitude + " " + altiude + " " + speed + " " + veld + " " + satno + " "+gpsfix + " " + tin + " " + tout + " " + volts + " " + debug);
       }

    }
}
