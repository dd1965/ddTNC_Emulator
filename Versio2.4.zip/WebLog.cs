﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TNCAX25Emulator
{
    class WebLog
    {
        

        public static void sendWebLog(string weblogstring)
        {         
            string url = Usersetting.weblogurl;
            string[] payLoad;
            payLoad = weblogstring.Split(',');
            string timerx = payLoad[2];
            string time = timerx;
            string[] ctime = timerx.Split(':');
            if (ctime.Length == 3)
                time = ctime[0] + ctime[1] + ctime[2];  

            try
            {               
                var nvc = new System.Collections.Specialized.NameValueCollection();
                nvc.Add("string_type", "ascii-stripped");
                nvc.Add("time_created",time);
                nvc.Add("metadata", "{}");
                //Add code here to switch call sign to PSB is required.
                nvc.Add("callsign", Usersetting.callsign);
                nvc.Add("string", weblogstring);
                var client = new System.Net.WebClient();
                var data = client.UploadValues(url, "POST", nvc);
                var res = System.Text.Encoding.ASCII.GetString(data);
                Console.WriteLine(res);
                //Console.ReadLine();
            }
            catch (Exception n)
            {
                Console.WriteLine(n.ToString());
            }
            
        }
       
    }
}
