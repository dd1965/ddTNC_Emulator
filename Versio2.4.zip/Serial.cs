﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TNCAX25Emulator
{
   
     class Serial
    {
        System.IO.Ports.SerialPort serialportref;

        public Serial(System.IO.Ports.SerialPort serialportref)
        {
            this.serialportref = serialportref;
        }
        public string[] getPorts(){

            string[] ports = System.IO.Ports.SerialPort.GetPortNames();
            return ports;
        }
        public string getthisPort()
        {          
            return serialportref.PortName;
        }
        public System.IO.Ports.SerialPort getSerialPortRef()
        {
            return this.serialportref;
        }
        public int openSerialPort(String comPort)
        {
            try
            {
              
                if (serialportref.IsOpen == true) serialportref.Close();
                serialportref.PortName = comPort;
                serialportref.Open();         
                return 0;

            }
            catch (Exception e)
            {
                MessageBox.Show("Open Com Port Result -> " + e.ToString(), "TNCAX25Emulator",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
        }
        public int closeSerialPort()
        {
            try
            {
                if (serialportref.IsOpen == true) serialportref.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show("Close Com Port Result -> " + e.ToString(), "TNCAX25Emulator",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
            return 0;
        }

    }
}
