﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Configuration;
using System.Windows.Forms;

namespace TNCAX25Emulator
{
     class ServerPort
    {
        
        object reference;
        const int LIMIT = 1; //1 concurrent clients   
        TcpListener listener;
        int portnumber = 1111;
        String localhost = "127.0.0.1";
        State state;
        int rxindex=0;
        byte[] rxBuffer; 
        public enum State
        {
            IDLE, HEADERDETECTED,ENDDETECTED
        };

        public ServerPort(object reference)
        {
            rxBuffer = new byte[255];
            try
            {
                

                if (Usersetting.serverport != null)
                {
                    try
                    {
                        string[] servercombineaddress = Usersetting.serverport.Split(':');
                        if (servercombineaddress.Length > 1)
                        {
                            localhost = "localhost";
                            portnumber = 1111;
                            Usersetting.serverport = localhost + ":" + portnumber.ToString();
                            Properties.Settings.Default.serverport = Usersetting.serverport;
                        }
                        else
                        {
                            localhost = servercombineaddress[0];
                            portnumber = Convert.ToInt32(servercombineaddress[1]);
                        }
                    }
                    catch (Exception e)
                    {
                        localhost = "localhost";
                        portnumber = 1111;
                        Usersetting.serverport = localhost + ":" + portnumber.ToString();
                        Properties.Settings.Default.serverport = Usersetting.serverport;

                    }

                }
                else
                {
                    localhost = "localhost";
                    portnumber = 1111; 
                    Usersetting.serverport = localhost + ":" + portnumber.ToString();
                    Properties.Settings.Default.serverport = Usersetting.serverport;
                   
                }
               
                IPAddress[] addresslist = Dns.GetHostAddresses(localhost);

                for (int i = 0; i < addresslist.Length; i++)
                {
                    if ((localhost = addresslist.ElementAt(i).ToString()).StartsWith(":"))
                    { 
                        //This an IPV6 format, so ignore.
                        continue;
                    }
                    else
                    {
                        //The first valid IPV4 found.
                        break;
                                                
                    }
                }

                IPAddress localAddr = IPAddress.Parse(localhost);
                listener = new TcpListener(localAddr, portnumber);
                this.reference = reference;
                listener.Start();

                for (int i = 0; i < LIMIT; i++)
                {
                    Thread t = new Thread(new ThreadStart(Service));
                    t.IsBackground = true;
                    t.Start();
                }
            }catch(Exception e){
                MessageBox.Show("Open TCPIP server port "+ Usersetting.serverport+" Result -> " + e.ToString(), "TNCAX25Emulator",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void tncPortServerRx(byte RxByte)
        {
            byte[] gpsByteCh = new byte[1];
            gpsByteCh[0] = RxByte;
            String TCPsrvrecv = ASCIIEncoding.ASCII.GetString(gpsByteCh);
            ((Form1)reference).SetTextRTTY(TCPsrvrecv);
            if (rxindex == 255)
            {
                state = State.IDLE;
                rxindex = 0;
            }       
            switch (state)
            {             
                case State.IDLE:
                    {
                        if (RxByte == 0x24)
                        {
                            state=State.HEADERDETECTED;
                            rxindex=0;
                            rxBuffer[rxindex] = RxByte;
                            rxindex++;
                        }
                    }
                    break;

                case State.HEADERDETECTED:
                    {
                        if (RxByte== 0x0A)
                        {
                            rxBuffer[rxindex] = RxByte;
                            MessageHandler.receivequeue.Enqueue(rxBuffer);
                            state = State.IDLE;
                            rxindex = 0;
                        }
                        else
                        {
                            rxBuffer[rxindex] = RxByte;
                            rxindex++;
                        }
                    }
                    break;
            }
            
        }

        public void Service()
        {
            while (true)
            {
                Socket soc = listener.AcceptSocket();

                try
                {
                    Stream s = new NetworkStream(soc);
                    StreamReader sr = new StreamReader(s);
                    StreamWriter sw = new StreamWriter(s);
                    sw.AutoFlush = true; // enable automatic flushing
                    int count = 0;
                    Boolean star = false;
                    while (true)
                    {
                       // string test= sr.ReadLine();
                      //  sr.Readline();
                       int readchar = sr.Read();
                       uint readchr = (uint)readchar;
                       byte rttyasciichar = (byte)readchr;
                       
                       //The following code is a kludge to emulate a /n 
                       //FLDIGI is not sending the /n
                        if (rttyasciichar == 0x2A)
                        {
                            star= true;
                        }
                          if (star){count++;
                         
                              
                        }
                       tncPortServerRx(rttyasciichar);
                       if (count == 5)
                       {
                           count = 0;
                           star = false;
                           rttyasciichar = 0x0A;
                           tncPortServerRx(rttyasciichar);
                       }

                    }
                    s.Close();
                }
                catch (Exception e){
               
                  //  MessageBox.Show("Server Port Error " + Usersetting.serverport + " Result -> " + e.ToString(), "TNCAX25Emulator",
                  //MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                soc.Close();

            }
        }
    }
}
    
	