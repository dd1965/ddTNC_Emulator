﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using mshtml;
using System.IO;
using WinMM;


/* Version 1.1 25/12/2012 VK3TBC experimental prototype 
 * The source code is distributed freely. Use at your own risk.
-Added some exception error handling on the TCPIP port
-Added exception error handling on GPS string
-Added exception handling if cannot write to serial port
-Added new static class so that you can report on all paramters on text boxes
-Added locks on all text boxes that are not suppossed to be updated
-Added 100 lines for max scrolling to avoid out of memory error.
-Added APRS.FI web page for local testing
-Version 1.2
- Added a separate menu for callsign, path and comport. Now validates on window closure.
- It now persists the values of the comport, callsign and path.
- Still need to clean up a lot of the code though.
- Version 1.3
- Added sound capable AX25 out
- Added option to turn kiss tnc off or on (also true for sound)
- Persisted the value of the check box.
- Added a timer function to not send on every packet received.
- Added more information on the status.
- Added 300 baud sending, this is UNTESTED. Uses 1600 and 1800 tones.
- Left channel 1200 baud right channel 300 baud.
- TODO allow for more than 1 sound card. Allow set up of configuration per port. All different callsign on ports
-Version 1.4 09/03/2013
-Added ability to specify server port. Not sure why this is warranted (but it's there)
-Version 1.5 15/03/2013
-Added functionality to fix the screen update error which was causing multi threading issues.
- Version 1.6 17/03/2013
-Added 2 extra parameters Debug and Vertical Speed
-Added new string for test packet
-Corrected error on the number of lat long bytes with leading/trailing zeroes.
- Version 1.7 03/04/2013
-Fixed bug on conversion minus sign.
-Version 1.8 04/04/2013
- Removed popup from indicating GPS error
- Put in a quick fix to default to sound card 0 if USB sound card is no longer there.
- Versopm 1.10 Removed pop up on TCP port failure. 
-Version 2.0 13/04/2013
- Major upgrade to include FFT and RTTY internal decoder. Also, you can now open and close the sound port correctly without a restart.
- Version 2.3 19/04/2013 Few bugs fixed on persisting values, refactored lat and long, fixed mouseptr confirm position. 
- Version 2.4 25/04/2013 New message handler, some refactoring; needs a lot more refactoring and simplification of the message handler.
  Added logging.
 */
namespace TNCAX25Emulator
{
   
    public partial class Form1 : Form
    {
        Boolean Close = false;
        int pictureBox_X;
        ProcessData pd;
        graph gp;
        Demodulator dm;
        RttyDecoder1 rttydec;
        Serial serialporthandlerTNC;
       // Serial serialporthandlerRTTY;
        ServerPort sp;
        Kiss kiss;
        GPS gps;
        Aprs aprs;
        Andyprotocol aprot;
        WaveOut waveOut;
        WaveIn waveIn;
        int bytecount = 0;
        byte[] rttyRXGPS;
        GenerateTone gt;
        Hdlc hdlc;
        Point oldxspec;
        Point oldxtext;
        MessageHandler mh;
        WebLog wblg;
       
        byte[] receivedAPRSmessage;
        private static ReaderWriterLockSlim _lock = new ReaderWriterLockSlim();
        public Form1()
        {
           
            InitializeComponent();
           
            /*using (var wb = new WebClient())
            {
              var data = new NameValueCollection();
              data["username"] = "myUser";
              data["password"] = "myPassword";

             var response = wb.UploadValues(url, "POST", data);
            }
             * 
             * 
             * 
             var post_test = JSON.stringify(data)
            httpreq.open("POST", "/habitat/message", true);
            httpreq.setRequestHeader("Content-type", "application/json");
            httpreq.setRequestHeader("Content-length", post_text.length);
            httpreq.send(post_text);

            The JSON sent should be an “object” (JSON ‘object’; python ‘dict’) with four name/value pairs: callsign, type, time and data, like in this example:

            {
             "callsign": "M0ZDR",
             "type": "LISTENER_INFO",
             "time_created": 1295103598,
             "time_uploaded": 1295103707,
             "data": { "name": "Daniel Richman", "icon": "car" }
}


             
            */

            oldxspec = new Point(9, 27);
            oldxtext = new Point(279, 27);
           
            serialporthandlerTNC = new Serial(serialPort1); //TNC Port
           // serialporthandlerRTTY = new Serial(serialPort2);
           // sp = new ServerPort(1111,this);
            sp = new ServerPort(this);
            kiss = new Kiss();
            gps = new GPS();
            aprot = new Andyprotocol();
            aprs = new Aprs(this);
            rttyRXGPS = new byte[255];
            string savedcomport;
           
            hdlc = new Hdlc();
            gp = new graph(spectrumBox1);
            dm = new Demodulator(this);
            rttydec = new RttyDecoder1(Config.baudrate, dm, this);
            mh = new MessageHandler(this, aprs, aprot, hdlc, kiss);
            timer1.Stop();
            try
            {
               
              
               Usersetting.callsign = Properties.Settings.Default.callsign;
               Usersetting.path = Properties.Settings.Default.path;
               string temp = Properties.Settings.Default.PropertyValues.ToString();

               savedcomport = Properties.Settings.Default.comport;
               Usersetting.comport=Properties.Settings.Default.comport;
               Usersetting.kissenabled = Properties.Settings.Default.kissenabled;
               Usersetting.soundEnabledCB = Properties.Settings.Default.soundEnableCB;
               Usersetting.soundEnabledCBIn = Properties.Settings.Default.SoundEnabledIn;
                Usersetting.serverport = Properties.Settings.Default.serverport;
               Usersetting.mapenabled = Properties.Settings.Default.mapenabled;
              
               Usersetting.soundcardindexOut = Convert.ToInt32(Properties.Settings.Default.soundport);

               if (Usersetting.kissenabled == true)
               {
                   if (savedcomport != null)
                       serialporthandlerTNC.openSerialPort(savedcomport);
                   mh.setSerialport(serialporthandlerTNC);
               }
               if (Usersetting.soundEnabledCB)
               {
                   if (Properties.Settings.Default.soundport == null)
                       Usersetting.soundcardindexOut = 0;     //Default to the first sound card. This may happen if you disconnected a USB sound card
                   initialiseSoundCardOut();
               }
             
               Usersetting.baud = Convert.ToInt32(Properties.Settings.Default.baud);
               Usersetting.mark = Convert.ToInt32(Properties.Settings.Default.markfreq);
               Usersetting.offset = Convert.ToInt32(Properties.Settings.Default.offset);
               Usersetting.rttyenabled=Properties.Settings.Default.rttyenabledch;
               Usersetting.reverseenabled = Properties.Settings.Default.reverseenabled;
               Usersetting.afcenabled = Properties.Settings.Default.afcenabled;
               if (Usersetting.rttyenabled)
               {
                   if (Usersetting.soundEnabledCBIn)
                   {
                       if (Properties.Settings.Default.soundportin == null)
                           Usersetting.soundcardindexIn = 0;     //Default to the first sound card. This may happen if you disconnected a USB sound card
                       initialiseSoundCardIn();
                   }
                   pd = new ProcessData(waveIn, spectrumBox1, dm, gp, rttydec);
                   pd.updatefilterMarkfreq(Usersetting.mark);
                   gp.setScreenFreq(Usersetting.mark);
                   pd.updateoffset(Usersetting.offset);
                   pd.afcenabled(Usersetting.afcenabled);
                   dm.changeBaud(Usersetting.baud);
                   rttydec.changeBaud(Usersetting.baud);
                   dm.changeReverse(Usersetting.reverseenabled);
                   rttydec.changeReverse(Usersetting.reverseenabled);
               }
               else
               {
                   gp.clear("Not enabled");
               }


             
            }
            catch (Exception e) {
                Usersetting.kissenabled = false;
                Usersetting.soundEnabledCB = false;
                Usersetting.soundEnabledCBIn = false;
                Usersetting.rttyenabled = false;

              // MessageBox.Show("Config error> " + e.ToString(), "TNCAX25Emulator",
               //MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            Logging log = new Logging();
            Usersetting.logging = true;
            wblg = new WebLog();
            Usersetting.weblogging = false;
            Usersetting.weblogurl = @"http://habitat.habhub.org/transition/payload_telemetry";
          
           
            if (!Usersetting.rttyenabled)
            {
                spectrumBox1.Visible = false;
                richTextBox1.AutoSize = true;
                richTextBox1.Location = oldxspec;
                richTextBox1.Width = 412 + 256;
                richTextBox1.AutoSize = false;
            }

            if (Usersetting.mapenabled)
            {

                string address = "http://aprs.fi/#!call=a%2F" + Usersetting.callsign + "&timerange=3600&tail=3600";

                /*    string address = "http://aprs.fi";*/
                try
                {
                    webBrowser1.Navigate(new Uri(address));

                }
                catch (System.UriFormatException)
                {
                    return;
                }
            }
            else

            {
                webBrowser1.Visible = false;
                this.Size = new Size(495, this.Size.Height);
               
            }

           /* richTextBox1.SelectionStart = richTextBox1.Text.Length;
            richTextBox1.ScrollToCaret();
            richTextBox1.Refresh();*/
            /*Test stub for message handling crc
            string TestString = "$$PSB,0001,000000,0.0,0.0,0,0,0,0,107,26,7656*16B3";
            //$$PSB,0001,000000,0.0,0.0,0,0,0,0,107,26,7656*16B3

            byte[] testarray = new byte[TestString.Length * sizeof(char)];
            System.Buffer.BlockCopy(TestString.ToCharArray(), 0, testarray, 0, testarray.Length);
            byte[] realarray = new byte[testarray.Length / 2];
            int index = 0;
            for (int i = 0; i < realarray.Length; i++)
            {
                realarray[i] = testarray[index];
                index = index + 2;

            }
            for (int i = 0; i < realarray.Length; i++)
            {
                tncPortServerRx(realarray[i]);
            }
           // string testcrc = aprot.processRXrttystring(realarray);*/
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        { //TNC Data
            
            //SetTextTNC(serialPort1.ReadExisting());//TODO KISS receive will block
        }
        
        public void SetTextTNC(string text)
        {
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.
            if (this.richTextBox1.InvokeRequired)
              
                {
                    MethodInvoker del = delegate
                    {
                        SetTextTNC(text);
                    };
                    this.Invoke(del);
                    return;
                }
               richTextBox1.AppendText("TNC "+text);
            //   richTextBox1.ScrollToCaret(); 
            
            
        }




        private void Form1_Load(object sender, EventArgs e)
        {

        }

       
       
      /*  private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            String comPort = comboBox1.SelectedItem.ToString();
            serialporthandlerTNC.openSerialPort(comPort);
          
        }*/

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

       
       

        public void updatereceivedfields()
        {
            if (this.sequenceno.InvokeRequired)
            {
                MethodInvoker del = delegate
                {
                    updatereceivedfields();
                };
                this.Invoke(del);
                return;
            }
            sequenceno.Text = TNCAX25Emulator.Receivedparameters.sequence;
            time.Text = TNCAX25Emulator.Receivedparameters.time;
            latitude.Text = TNCAX25Emulator.Receivedparameters.lat;
            longitude.Text = TNCAX25Emulator.Receivedparameters.longitude;
            speed.Text = TNCAX25Emulator.Receivedparameters.speed;
            tempin.Text = TNCAX25Emulator.Receivedparameters.tin;
            tempout.Text = TNCAX25Emulator.Receivedparameters.tout;
            numofsat.Text = TNCAX25Emulator.Receivedparameters.satno;
            gpsfix.Text = TNCAX25Emulator.Receivedparameters.gpsfix;
            voltage.Text = TNCAX25Emulator.Receivedparameters.volts;
            altitude.Text = TNCAX25Emulator.Receivedparameters.altiude;
            debug.Text = TNCAX25Emulator.Receivedparameters.debug;
            veld.Text = TNCAX25Emulator.Receivedparameters.veld;
            ballooncallsign.Text = TNCAX25Emulator.Receivedparameters.psbcallsign;
        
        }
        public void SetTextRTTY(string text)
        {
          try{
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.
            if (this.richTextBox1.InvokeRequired)
            {
                MethodInvoker del = delegate
                {
                    SetTextRTTY(text);
                };
                 
                this.Invoke(del);
                return;
            }
            richTextBox1.AppendText(text);
          //  richTextBox1.ScrollToCaret(); 
          }catch(Exception e){}
             
           
        }
        public void SetTextRTTYGood(string text)
        {
            try
            {
                // InvokeRequired required compares the thread ID of the
                // calling thread to the thread ID of the creating thread.
                // If these threads are different, it returns true.
                if (this.richTextBox1.InvokeRequired)
                {
                    MethodInvoker del = delegate
                    {
                        SetTextRTTYGood(text);
                    };

                    this.Invoke(del);
                    return;
                }
                richTextBox1.SelectionColor = Color.Yellow;
                richTextBox1.AppendText(text);
                //  richTextBox1.ScrollToCaret(); 
            }
            catch (Exception e) { }


        }

        public void SetTextAPRS(string text)
        {
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.
            if (this.richTextBox1.InvokeRequired)
            {
                MethodInvoker del = delegate
                {
                    SetTextAPRS(text);
                };
                this.Invoke(del);
                return;
            }
            richTextBox1.AppendText("(APRS)" + text);
           // richTextBox1.ScrollToCaret(); 
         }

       

       /* private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

           
           
            if (e.KeyChar == (char)13)
            {
                if (validdatecallsign(textBox1.Text))
                { textBox1.BackColor = Color.White; }
                else
                {
                    textBox1.BackColor = Color.Red;
                }
               
            }
        }*/

      /*  private void textBox1_MouseLeave(object sender, EventArgs e)
        {
            if (validdatecallsign(textBox1.Text))
            { textBox1.BackColor = Color.White; }
            else
            {
                textBox1.BackColor = Color.Red;
            }
               
        }*/
        private Boolean validdatecallsign(String tBxcallsign)
        {
            Boolean valid = true;
            try
            {
                int SSID = 0;
                
                {
                    if (tBxcallsign.Length <= 9)
                    {
                        string[] callsignandSSID = tBxcallsign.Split('-');
                        if (callsignandSSID.Length > 1)
                        {

                            char[] ssid = callsignandSSID[1].ToArray();
                            if (ssid.Length < 3)
                            {
                                if (ssid.Length > 1)
                                {
                                    string ascii = "" + ssid[1];
                                    int SSIDno = Convert.ToInt32(ascii, 10);
                                    ascii = "" + ssid[0];
                                    int SSIDxten = Convert.ToInt32(ascii, 10) * 10;
                                    SSID = SSIDxten + SSIDno;
                                    if (SSID > 15)
                                    {
                                        valid = false;
                                    }
                                }
                                else
                                {
                                    string ascii = "" + ssid[0];
                                    SSID = Convert.ToInt32(ascii, 10);
                                }
                            }
                            else
                            {
                                valid = false;

                            }
                        }
                        if ((callsignandSSID[0].Length < 7) & (SSID < 16))
                        {
                            valid = true;
                        }
                        else
                        {
                            valid = false;
                        }
                        //  
                    }
                    else
                    {
                        valid = false;
                    }

                }
            }
            catch (Exception e)
            {
                valid = false;
            }
            return valid;
        }

    /*    private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
           

            if (e.KeyChar == (char)13)
            {
                if (validdatecallsign(textBox2.Text))
                { textBox2.BackColor = Color.White; }
                else
                {
                    textBox2.BackColor = Color.Red;
                }

            }
        }
*/
       /* private void textBox2_MouseLeave(object sender, EventArgs e)
        {
            if (validdatecallsign(textBox2.Text))
            { textBox2.BackColor = Color.White; }
            else
            {
                textBox2.BackColor = Color.Red;
            }

        }
        */
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                serialPort1.Close();
                pd.Halt();
                Thread.Sleep(100);
                pd.Close(); //Check this.
                if ((waveOut != null) && (Usersetting.soundEnabledCB == true))
                    waveOut.Close();//Change this to detect for null;
              //  if ((waveIn != null) && (Usersetting.soundEnabledCBIn == true))
             //       waveIn.Close();
                sp = null;
                kiss = null;
                gps = null;
                aprs = null;
                aprot = null;
            }
            catch (Exception er)
            {Console.WriteLine("Error detected in form closing"+er.ToString());
            }
             
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

       
           /* HtmlElement head = webBrowser1.Document.GetElementsByTagName("head")[0];
            HtmlElement scriptEl = webBrowser1.Document.CreateElement("script");
            scriptEl.SetAttribute("type", "text/javascript");
            IHTMLScriptElement element = (IHTMLScriptElement)scriptEl.DomElement;
            string srJquery = File.ReadAllText("jsscript.txt");
            element.text = srJquery;
            head.AppendChild(scriptEl);  */

 
         

            

         /*    HtmlElement head = webBrowser1.Document.GetElementsByTagName("head")[0];
             HtmlElement script = webBrowser1.Document.CreateElement("script");
            IHTMLScriptElement domElement = (IHTMLScriptElement)script.DomElement;
            domElement.text = "<p>he_track = \"VK3TBC-2\";src=\"http://aprs.fi/js/embed.js\"</p>";
            head.AppendChild(script);*/
          //  var jsCode = "alert('<p><script type=\"text/javascript\">he_track = \"VK3TBC-2\";</script><script type=\"text/javascript\" src=\"http://aprs.fi/js/embed.js\"></script></p>');";
         //  webBrowser1.Document.InvokeScript("execScript", new Object[] { jsCode, "JavaScript" });

         
       

        private void richTextBox1_TextChanged_1(object sender, EventArgs e)
        {
          if (richTextBox1.Lines.Length >100) { //Clear screen on 100 lines to avoid running out of space
              richTextBox1.Clear();
          }
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {

                Close = true;
                rttydec.Close();
                // pd.Close();
                Properties.Settings.Default.Save();
            }
            catch (Exception er1)
            {
                Console.WriteLine("Error detected in form closing"+er1.ToString());
            }
            
          
        }

        private void contextMenuStrip3_Opening(object sender, CancelEventArgs e)
        {

        }

       
        private void ccomportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Communication


            PopUpcomm popup = new PopUpcomm();
            popup.setList(serialporthandlerTNC.getPorts());
            popup.setListsoundcardOut();
            popup.setListsoundcardIn();
            popup.setListAPRSmsginterval();
            popup.setServerport();
            popup.setMapenablement();
            popup.ShowDialog();
            if (Usersetting.kissenabled)
                serialporthandlerTNC.openSerialPort(Usersetting.comport);
            else serialporthandlerTNC.closeSerialPort();
            if(Usersetting.soundEnabledCB)
               initialiseSoundCardOut();

            if (Usersetting.soundEnabledCBIn)
                initialiseSoundCardIn();
            else closeRTTY();

            if (Usersetting.APRSintervalindex != 0)
            {
                if (Usersetting.APRSintervalindex == 1) timer1.Interval = 30 * 1000;
                if (Usersetting.APRSintervalindex == 2) timer1.Interval = 60 * 1000;
                if (Usersetting.APRSintervalindex == 3) timer1.Interval = 120 * 1000;
                if (Usersetting.APRSintervalindex == 4) timer1.Interval = 300 * 1000;
                timer1.Start();
            }
            else
            {
                timer1.Stop();
            }

            popup.Dispose();
        }

        private void testToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked_1(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void callsignToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PopUpcallsign popup = new PopUpcallsign(this);
            popup.ShowDialog();
            popup.Dispose();
        }

        private void testToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //Test
            //Test stub for message handling crc
            // string TestString = "$$PSB,0001,000000,0.0,0.0,0,0,0,0,107,26,7656*16B3";
            //-> string TestString =   "$$PSB,0163,000000,0.0,0.0,0,0,0,0,107,107,8834*5508";
            //$$PSB,599,07:17:53,-36.2431,143.1503,431,5.12,-2.14,9,3,34,31,3032,_*BBD7
            //	msg	"PSB,599,07:17:53,-36.2431,143.1503,431,5.12,-2.14,9,3,34,31,3032,_*F528"	string

           // string TestString = "$$PSB,0110,024228,-37.7536,144.9264,46,0,7,1,-13,52,7125*F1DD";
           // string TestString = "$$PSB,599,07:17:53,-36.2431,143.1503,431,5.12,-2.14,9,3,34,31,3032,_*F528";
             string TestString = "$$PSB,15,07:35:35,-37.7534,144.9264,31,0.14,0.36,5,3,0.0,0.0,2533,_*D40E";


            byte[] testarray = new byte[TestString.Length * sizeof(char)];
            System.Buffer.BlockCopy(TestString.ToCharArray(), 0, testarray, 0, testarray.Length);
            byte[] realarray = new byte[testarray.Length / 2];
            int index = 0;
            for (int i = 0; i < realarray.Length; i++)
            {
                realarray[i] = testarray[index];
                index = index + 2;

            }
            for (int i = 0; i < realarray.Length; i++)
            {
                sp.tncPortServerRx(realarray[i]);
            }
            sp.tncPortServerRx(0x0A);
        }

        private void initialiseSoundCardOut()
        {

            if (waveOut == null)//TODO is there a way to change sound cards without exiting?
            {
                waveOut = new WaveOut(WinMM.WaveOut.GetDeviceCaps(Usersetting.soundcardindexOut).DeviceId);
                waveOut.Open(Config.waveformat);
                gt = new GenerateTone(waveOut);
                mh.setWaveOutRefandToneRef(waveOut,gt);
            }
            else
            {
                waveOut.Stop();
                waveOut.Dispose();
                waveOut = new WaveOut(WinMM.WaveOut.GetDeviceCaps(Usersetting.soundcardindexOut).DeviceId);
                waveOut.Open(Config.waveformat);
                gt = new GenerateTone(waveOut);
                mh.setWaveOutRefandToneRef(waveOut, gt);
            }
        }
        private void initialiseSoundCardIn()
        {
            if (waveIn == null)
                waveIn = new WaveIn(WinMM.WaveIn.GetDeviceCaps(Usersetting.soundcardindexIn).DeviceId);
            else
            {
                if (spectrumBox1.Visible)
                {
                    waveIn.Stop();
                    waveIn.Dispose();
                    waveIn = new WaveIn(WinMM.WaveIn.GetDeviceCaps(Usersetting.soundcardindexIn).DeviceId);
                    openRTTY();
                }else
                {
                    closeRTTY();
                    waveIn = new WaveIn(WinMM.WaveIn.GetDeviceCaps(Usersetting.soundcardindexIn).DeviceId);
                    openRTTY();
                }
                
               // waveIn.Close();
               // waveIn = new WaveIn(WinMM.WaveIn.GetDeviceCaps(Usersetting.soundcardindexIn).DeviceId);
               //TODO if you close the wave in, you need to close the pd and restablish it.
            }
        }
        public void receivedMessage(byte[] msg){
            _lock.EnterWriteLock();
            receivedAPRSmessage=msg;
            _lock.ExitWriteLock();
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            string value;
            if (receivedAPRSmessage != null)
            {
                if (Usersetting.kissenabled)
                {
                    byte[] encodedkissbuffer = kiss.encodeKissFrame(receivedAPRSmessage);
                    try
                    {
                        serialPort1.Write(encodedkissbuffer, 0, encodedkissbuffer.Length); //Send data to Packet Engine Pro
                        value = "Sending to TNC on " + serialPort1.PortName + " " + Usersetting.callsign + " via " + Usersetting.path + " " + TNCAX25Emulator.Receivedparameters.payload() + " " + textBox3.Text;
                        SetTextAPRS(value + "\n");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Cannot write to serial port -> ", "TNCAX25Emulator",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                }
                if (Usersetting.soundEnabledCB)
                    if (waveOut != null)
                    {
                        hdlc.senddata(receivedAPRSmessage, gt);
                        value = "Sending to Sound Card " + " " + Usersetting.callsign + " via " + Usersetting.path + " " + TNCAX25Emulator.Receivedparameters.payload() + " " + textBox3.Text;
                        SetTextAPRS(value + "\n");
                    }


                receivedAPRSmessage = null;

            }

        }

        private void spectrumBox1_Click(object sender, EventArgs e)
        {

           if (pd != null)
           {
            if(gp.setscreenPTRconform(pictureBox_X))
                pd.updatefilterMark(pictureBox_X);
            
           }
        }

        private void spectrumBox1_MouseHover(object sender, EventArgs e)
        {

        }

        private void spectrumBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (pd != null)
            {
                pictureBox_X = e.X;
                gp.setscreenPTR(e.X);
            }
        }

        private void spectrumBox1_MouseLeave(object sender, EventArgs e)
        {
            pictureBox_X = -1;
            gp.setscreenPTR(-1);
        }

        private void rttyConfigToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(pd!=null)pd.Halt();
            Thread.Sleep(100);

            PopUprtty1 popup = new PopUprtty1();
            popup.setSettings();
            popup.ShowDialog();
            popup.Dispose();
            if (pd == null)
            {
                if (Usersetting.rttyenabled == false)
                {
                    
                    spectrumBox1.Visible = false;

                    spectrumBox1.Visible = false;
                    richTextBox1.AutoSize = true;
                    richTextBox1.Location = oldxspec;
                    richTextBox1.Width = 412 + 256;
                    richTextBox1.AutoSize = false;
                    return;
                }
                setupRtty();
                
            }
            else
            {
                if (Usersetting.rttyenabled == true)
                {
                    pd.updatefilterMarkfreq(Usersetting.mark);
                    gp.setScreenFreq(Usersetting.mark);
                    pd.updateoffset(Usersetting.offset);
                    rttydec.changeBaud(Usersetting.baud);
                    pd.afcenabled(Usersetting.afcenabled);
                    dm.changeBaud(Usersetting.baud);
                    dm.changeReverse(Usersetting.reverseenabled);
                    rttydec.changeReverse(Usersetting.reverseenabled);
                    spectrumBox1.Visible = true;
                    richTextBox1.AutoSize = true;
                    richTextBox1.Location = oldxtext;
                    richTextBox1.Width = 412;
                    richTextBox1.AutoSize = false;

                }
                else
                {
                    
                    pd.Halt();
                    Thread.Sleep(100);
                    pd.Close();
                    waveIn.Close();                                     
                    Usersetting.soundEnabledCBIn = false;
                    Properties.Settings.Default.SoundEnabledIn = Usersetting.soundEnabledCBIn;      
                    gp.clear("Not enabled");
                    pd = null;
                    waveIn = null;
                    spectrumBox1.Visible = false;
                    richTextBox1.AutoSize = true;
                    richTextBox1.Location = oldxspec;
                    richTextBox1.Width = 412 + 256;
                    richTextBox1.AutoSize = false;
                }
            }
            if (pd!=null) pd.cont();
        }
    
        public void setupRtty()
        {
            try
            {
                if (Usersetting.soundEnabledCBIn)
                {
                  /*  if (waveIn == null)
                        Usersetting.soundcardindexIn = 0;     //Default to the first sound card. This may happen if you disconnected a USB sound card
                    initialiseSoundCardIn();*/

                    pd = new ProcessData(waveIn, spectrumBox1, dm, gp, rttydec);
                    pd.updatefilterMarkfreq(Usersetting.mark);
                    gp.setScreenFreq(Usersetting.mark);
                    pd.updateoffset(Usersetting.offset);
                    pd.afcenabled(Usersetting.afcenabled);
                    dm.changeBaud(Usersetting.baud);
                    dm.changeReverse(Usersetting.reverseenabled);
                    rttydec.changeReverse(Usersetting.reverseenabled);
                    rttydec.changeBaud(Usersetting.baud);
                    spectrumBox1.Visible = true;
                    richTextBox1.AutoSize = true;
                    richTextBox1.Location = oldxtext;
                    richTextBox1.Width = 412;
                    richTextBox1.AutoSize = false;
                    
                }
                else
                {
                    MessageBox.Show("Error - Set up sound card input first ", "TNCAX25Emulator",
                     MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Usersetting.rttyenabled = false;
                    Properties.Settings.Default.rttyenabledch = Usersetting.rttyenabled;
                    
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Error - PD ", "TNCAX25Emulator",
                       MessageBoxButtons.OK, MessageBoxIcon.Error);
               
               
            }
        }

        private void serialPort1_ErrorReceived(object sender, System.IO.Ports.SerialErrorReceivedEventArgs e)
        {

        }
        private void closeRTTY()
        {
            if (waveIn != null)
            {
                waveIn.Stop();
                waveIn.Dispose();
            }
            Usersetting.rttyenabled = false; ;
            Properties.Settings.Default.rttyenabledch = Usersetting.rttyenabled;
            spectrumBox1.Visible = false;
            richTextBox1.AutoSize = true;
            richTextBox1.Location = oldxspec;
            richTextBox1.Width = 412 + 256;
            richTextBox1.AutoSize = false;
            gp.clear("Not enabled");
            if (pd == null) return;
            pd.Halt();
            Thread.Sleep(100); 
            pd.Close();
            pd = null;
         //   Usersetting.soundEnabledCBIn = false;
         //   Properties.Settings.Default.SoundEnabledIn = Usersetting.soundEnabledCBIn;
           

        }
        private void openRTTY()
        {
            pd = new ProcessData(waveIn, spectrumBox1, dm, gp, rttydec);
            pd.updatefilterMarkfreq(Usersetting.mark);
            pd.updateoffset(Usersetting.offset);
            pd.afcenabled(Usersetting.afcenabled);
            dm.changeBaud(Usersetting.baud);
            dm.changeReverse(Usersetting.reverseenabled);
            rttydec.changeReverse(Usersetting.reverseenabled);
            rttydec.changeBaud(Usersetting.baud);
            Usersetting.rttyenabled = true; ;
            Properties.Settings.Default.rttyenabledch = Usersetting.rttyenabled;
            spectrumBox1.Visible = true;
            richTextBox1.AutoSize = true;
            richTextBox1.Location = oldxtext;
            richTextBox1.Width = 412;
            richTextBox1.AutoSize = false;
        }
        public string getTextbox3info()
        {
            return textBox3.Text;
        }

        private void logBox_CheckedChanged(object sender, EventArgs e)
        {
          
        }
        private static readonly DateTime UnixEpoch =
    new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);

        public static long GetCurrentUnixTimestampMillis()
        {
            return (long)(DateTime.UtcNow - UnixEpoch).TotalMilliseconds;
        }

        public static DateTime DateTimeFromUnixTimestampMillis(long millis)
        {
            return UnixEpoch.AddMilliseconds(millis);
        }

        public static long GetCurrentUnixTimestampSeconds()
        {
            return (long)(DateTime.UtcNow - UnixEpoch).TotalSeconds;
        }

        public static DateTime DateTimeFromUnixTimestampSeconds(long seconds)
        {
            return UnixEpoch.AddSeconds(seconds);
        }

        private void loggingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PopUplogging popup = new PopUplogging();
            popup.setSettings();
            popup.ShowDialog();
            popup.Dispose();
        }
    }
}
/*
 * static byte[] GetBytes(string str)
{
    byte[] bytes = new byte[str.Length * sizeof(char)];
    System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);
    return bytes;
}

static string GetString(byte[] bytes)
{
    char[] chars = new char[bytes.Length / sizeof(char)];
    System.Buffer.BlockCopy(bytes, 0, chars, 0, bytes.Length);
    return new string(chars);
}
*/