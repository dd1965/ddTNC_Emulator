﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WinMM;
using System.Collections.Concurrent;

namespace TNCAX25Emulator
{
    class GenerateTone
    {
        private Complex[] y = new Complex[2];
        double[] buf = new double[Config.bufferisizefor1200baudtone];
        double[] buf2 = new double[Config.bufferisizefor300baudtone];
        double w;
        byte[] signalbyteData = new byte[Config.bufferisizefor1200baudtone * 4]; //Assumes 16bit, 2 channel
        byte[] signalbyteData2 = new byte[Config.bufferisizefor300baudtone * 4];
        int amplitude = 8000;
        ConcurrentQueue<double[]> soundOutbufferQueue = new ConcurrentQueue<double[]>();
        WaveOut waveout;
        public GenerateTone(WaveOut waveout)
        {
            this.waveout = waveout;
            y[0].r = Math.Cos(0); // initial vector at phase phi 
            y[0].i = Math.Sin(0);
        }


        public void sendAX25tone1200BAUD(int tone)
        {
           

                if (tone == 0)
                {
                    w = (2 * Math.PI * 1200 / Config.samplingrate);
                }
                else
                {
                    w = (2 * Math.PI * 2200 / Config.samplingrate);
                }


                for (int t = 0; t < Config.bufferisizefor1200baudtone; t++)
                {
                    buf[t] = quadratureOscillator(w);

                }
                
                int j = 0;
                for (int b = 0; b < (buf.Length); b++)
                {
                    short tmp = (short)Math.Round(buf[b] * amplitude);

                    signalbyteData[j++] = (byte)(tmp & 0xFF);
                    signalbyteData[j++] = (byte)((tmp >> 8) & 0xFF);
                    signalbyteData[j++] = 0;//(byte)(tmp & 0xFF);
                    signalbyteData[j++] = 0;//(byte)((tmp >> 8) & 0xFF);
                }
                waveout.Write(signalbyteData);
            

        }
        public void sendAX25tone300BAUD(int tone)
        {


            if (tone == 0)
            {
                w = (2 * Math.PI * 1600 / Config.samplingrate);
            }
            else
            {
                w = (2 * Math.PI * 1800 / Config.samplingrate);
            }


            for (int t = 0; t < Config.bufferisizefor300baudtone; t++)
            {
                buf2[t] = quadratureOscillator(w);

            }

            int j = 0;
            for (int b = 0; b < (buf2.Length); b++)
            {
                short tmp = (short)Math.Round(buf2[b] * amplitude);

                signalbyteData2[j++] = 0;//(byte)(tmp & 0xFF);
                signalbyteData2[j++] = 0;// (byte)((tmp >> 8) & 0xFF);
                signalbyteData2[j++] = (byte)(tmp & 0xFF);
                signalbyteData2[j++] = (byte)((tmp >> 8) & 0xFF);
            }
            waveout.Write(signalbyteData2);


        }
         
        
        
        public double quadratureOscillator(double w)
        {
            double dr = Math.Cos(w); /* dr,di are used to rotate the vector */
            double di = Math.Sin(w);
            /*
                if (bufindex == 0)
            {
                y[0].r = Math.Cos(0); // initial vector at phase phi 
                y[0].i = Math.Sin(0);
            }
           */
            for (int n = 1; n < y.Length; n++)
            {
                y[n].r = dr * y[n - 1].r - di * y[n - 1].i;
                y[n].i = dr * y[n - 1].i + di * y[n - 1].r;
                double mag_sq = y[n].r * y[n].r + y[n].i * y[n].i;
                y[n].r = y[n].r * (3 - (mag_sq)) / 2;
                y[n].i = y[n].i * (3 - (mag_sq)) / 2;
            }
            y[0] = y[1];
            return (y[1].r);
        }

    }

}
