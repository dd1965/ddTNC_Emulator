﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.Concurrent;

namespace TNCAX25Emulator
{
    class RttyDecoder1
    {
        Boolean close = false;
        static int THRESHOLDHI = 50;    //50 for nor 1000 for reverse?
        static int THRESHOLDLOW = 50;
        static int NOR = 50;
        static int REV = 225;//Coherent mod 14000
        Boolean bit = true;
        Boolean one = true;
        Boolean zero = false;
        Boolean reverse = false;
        int bitcountofsymbol=0;
        int bitcountofrxchar = 0;
        State state;
        byte rxchar = 0;   
        private int NUMOFBITS = 8;           //Set at 8 bits 
        private int symbol;
        private Demodulator demod;
        object reference;
        private Movingaveragefilter mavghi;
        private Movingaveragefilter mavglo;
        private Movingaveragefilter mavgout;

        float[] demodofinput;
        Statelayer1 statelayer1;
        int rxindex = 0;
        byte[] rxBuffer;
        public enum Statelayer1
        {
            IDLE, HEADERDETECTED, ENDDETECTED
        };



        public enum State
        {

            DETECTSTARTBIT, IDLE, DECODEBITS, WAITONESTOPBIT,PARITY, STOPBITEND
        };
        public RttyDecoder1(int baudRate, Demodulator demod, object reference)
        {
            this.demod = demod;
            this.reference = reference;
            symbol = Config.samplingrate / baudRate;       
            state = State.IDLE;
            mavghi = new Movingaveragefilter(8);
            mavglo = new Movingaveragefilter(8);
            mavgout = new Movingaveragefilter(symbol / 2);
            rxBuffer = new byte[255];
        }

        public virtual void demodulate(float[] input)
        {
            demodofinput = new float[input.Length];
          
            for (int i = 0; i < input.Length; i++)
            {
                demodofinput[i] = demod.demodulate(input[i]);
               
                if (demodofinput[i] > THRESHOLDHI)
                {
                    bit = true;//
                 //   if (reverse) bit=!bit;
                }
                else if (demodofinput[i] < THRESHOLDLOW)
                {
                    bit = false;//
                  //  if (reverse) bit = !bit;
                }
            
                decodebit(bit);
            }                
        }
        public virtual void demodulate1(float[] inputhigh, float[] inputlow)
        {
            
            demodofinput = new float[inputhigh.Length];
            float[] demodofhigh = new float[inputhigh.Length];
            float[] demodoflow = new float[inputhigh.Length];

            for (int i = 0; i < inputhigh.Length; i++)
            {
                demodofhigh[i] = Math.Abs(inputhigh[i]);                
                demodofhigh[i] = mavghi.runFilt(demodofhigh[i]);
                demodoflow[i] = Math.Abs(inputlow[i]);
                demodoflow[i] = mavglo.runFilt(demodoflow[i]);
                demodofinput[i] = demodofhigh[i] - demodoflow[i];//else demodofinput[i] = demodoflow[i] - demodofhigh[i];
                demodofinput[i] = mavgout.runFilt(demodofinput[i]);
            }

            for (int i = 0; i < inputhigh.Length; i++)
            {
              //  demodofinput[i] = demod.demodulate(input[i]);

                if (demodofinput[i] > THRESHOLDHI)
                {
                    bit = true;//
                    if (reverse) bit=!bit;
                
                }
                else if (demodofinput[i] < THRESHOLDLOW)
                {
                    bit = false;//
                    if (reverse) bit = !bit;
                }

                decodebit(bit);
            }
        }
        private void decodebit(Boolean bit)
        {
                switch (state)
                {

                    case State.IDLE:
                        {
                            if (bit==zero)
                            {
                                bitcountofsymbol = symbol-20;
                                if (reverse) bitcountofsymbol = bitcountofsymbol - 65;
                                state = State.DETECTSTARTBIT;
                            }
                            break;
                        }
                    case State.DETECTSTARTBIT:
                        {
                            if (bit==zero)
                            {
                                if (--bitcountofsymbol == 0)
                                {
                                    state = State.DECODEBITS;
                                    bitcountofsymbol = symbol / 2;                               
                                };
                            }
                            else
                            {
                                state = State.IDLE;
                            }
                            break;
                        }
                    

                    case State.DECODEBITS:
                        {
                           
                            if (--bitcountofsymbol == 0)
                            {
                                bitcountofrxchar++;
                                if (bit==one)
                                    rxchar = (byte)(rxchar | 128);

                              

                                if (bitcountofrxchar == NUMOFBITS)
                                {                                 
                                    bitcountofrxchar = 0;
                                    state = State.WAITONESTOPBIT;
                                    bitcountofsymbol = symbol;
                                }
                                else
                                {
                                    rxchar = (byte)(rxchar >> 1);
                                    bitcountofsymbol = symbol;
                                }
                            }
                            break;
                        }
                    case State.WAITONESTOPBIT:
                        {
                          
                            if (--bitcountofsymbol == 0)
                            {
                               
                                 bitcountofsymbol = symbol/10;
                                 state = State.STOPBITEND;
                             }

                           
                            break;
                        }
                    case State.PARITY:
                        {
                            //TODO: add this in the future if required
                            break;
                        }
                    case State.STOPBITEND:
                        {
                           
                            if (bit==one)
                            {
                                if (--bitcountofsymbol == 0)
                                {
                                    if(!close)
                                    rttyRx((byte)rxchar);
                                    rxchar = 0;
                                    state = State.IDLE;
                                }
                            }
                            else
                            {   //Framing error
                                char framchar = '-';
                                if (!close)
                                    rttyRx((byte)(framchar));
                                state = State.IDLE;
                            }

                            break;
                        }

                    default: break;
                }

            }
        public void changeBaud(int baud)
        {
            this.symbol = Config.samplingrate / baud;
        }
        public void changeReverse(Boolean rev)
        {
            if (rev)
            {
                THRESHOLDHI = REV;
                THRESHOLDLOW = REV;
                reverse = true;
            }
            else
            {
              THRESHOLDHI = NOR;
              THRESHOLDLOW = NOR;
               reverse = false;
            }
        }
        public void Close()
        {
            close = true;
        }
        public void rttyRx(byte RxByte)
        {
            byte[] gpsByteCh = new byte[1];
            gpsByteCh[0] = RxByte;
            String TCPsrvrecv = ASCIIEncoding.ASCII.GetString(gpsByteCh);
            ((Form1)reference).SetTextRTTY(TCPsrvrecv);
            if (rxindex == 255)
            {
                statelayer1 = Statelayer1.IDLE;
                rxindex = 0;
            }
            switch (statelayer1)
            {
                case Statelayer1.IDLE:
                    {
                        if (RxByte == 0x24)
                        {
                            statelayer1 = Statelayer1.HEADERDETECTED;
                            rxindex = 0;
                            rxBuffer[rxindex] = RxByte;
                            rxindex++;
                        }
                    }
                    break;

                case Statelayer1.HEADERDETECTED:
                    {
                        if ((RxByte == 0x0A)||(RxByte == 0x0D))
                        {
                            rxBuffer[rxindex] = RxByte;
                            MessageHandler.receivequeue.Enqueue(rxBuffer);
                            statelayer1 = Statelayer1.IDLE;
                            rxindex = 0;
                        }
                        else
                        {
                            rxBuffer[rxindex] = RxByte;
                            rxindex++;
                        }
                    }
                    break;
            }

        }


        }  
}
