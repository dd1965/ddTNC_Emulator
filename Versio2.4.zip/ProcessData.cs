﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Configuration;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using WinMM;
using System.Collections.Concurrent;

namespace TNCAX25Emulator
{
     class ProcessData
     {
        
         Boolean track = true;
         Boolean close = false;  
         int freqhi = Config.MARK;
         int freqlo = Config.MARK - Config.OFFSET;
         int timecnt=0;
         int offset = Config.OFFSET;
             
       
         FFTW fftw;
        
        
         int cnt = 0;
        
         graph gr;
         PictureBox spectrumBox1;
         float[] fftdisplay = new float[512];
         WaveIn waveIn;
         WaveOut waveOut;
         Demodulator demod;
        
        
         FFTfilter fftFilt;
         FFTfilter fftFiltLow;
         FFTfilter fftFiltHi;
         Agc agc;
        
         RttyDecoder1 rttyDecode1;
         Movingaveragefilter mavgFilter;
         LeastSquareFilter lstsqrfilt;

         double spaceTonepower = 0;
         double markTonepower = 0;
         int bwoffset;
       
            
        // Demodulator demod; 
         public ProcessData(WaveIn waveIn ,PictureBox pictureBox,Demodulator demod,graph gr,RttyDecoder1 rttyDecode)
        {
           //  demod = new Demodulator();
            
            
             this.gr = gr;
             bwoffset =  (int)((float)offset / ((float)Config.samplingrate / (float) Config.FFTRES));
             gr.filterBW(bwoffset);
             this.rttyDecode1 = rttyDecode;
             this.demod = demod;
             this.waveIn = waveIn;
            
             this.spectrumBox1 = pictureBox;
           
            fftw = new FFTW(1024);          
           // fftw.InitFFTW(Config.FFTRES);
            fftFiltHi = new FFTfilter(fftw);
            fftFiltHi.calcFilterFFTCoefficients(FFTfilter.BANDPASS, freqhi-50, 100, 2);
           
             fftFilt = new FFTfilter(fftw);
             fftFilt.calcFilterFFTCoefficients(FFTfilter.BANDPASS,900, 2000, 2);//1600 700
           
             fftFiltLow = new FFTfilter(fftw);
             fftFiltLow.calcFilterFFTCoefficients(FFTfilter.BANDPASS, freqlo - 50, 100, 2);

             agc = new Agc();
            
            demod.changefreq(freqhi, freqlo);                 
            mavgFilter = new Movingaveragefilter(8);//was 20
            lstsqrfilt = new LeastSquareFilter();
          

            waveIn.BufferSize = Config.FFTRES/2;//Set the audio input capture to the same as the FFT/2.Multiply by the number of channels.16 bits e.g. 2 bytes
            waveIn.DataReady += new EventHandler<DataReadyEventArgs>(WaveIn_DataReady);
            waveIn.Open(Config.waveformat);
            waveIn.Start();
           
        }



         private void WaveIn_DataReady(object sender, DataReadyEventArgs e)
         {
             if (close) return;
             float[] soundpoints = new float[(e.Data.Length / 4)];//was4
             float[] soundpointsmvag = new float[(e.Data.Length / 4)];
             soundpointsmvag = (ConvertToushortsoundin(e.Data, 0));
             for (int i = 0; i < soundpoints.Length; i++)
             {
                 soundpointsmvag[i]= agc.doAGC(soundpointsmvag[i]);
                //  soundpoints[i] = lstsqrfilt.runFilt4(soundpointsmvag[i]);
                //  soundpoints[i] =  mavgFilter.runFilt(soundpoints[i]);
                  soundpoints[i] = mavgFilter.runFilt(soundpointsmvag[i]);
             }
                      
             soundpoints = fftFilt.doFFTFilter(soundpoints);
                      
             byte[] signalbyteData = new byte[soundpoints.Length * 4];
             int ampl = 1;
             int j = 0;
            

             for (int b = 0; b < (soundpoints.Length); b++)
             {
                 short tmp = (short)Math.Round(soundpoints[b] * ampl);

                 signalbyteData[j++] = (byte)(tmp & 0xFF);
                 signalbyteData[j++] = (byte)((tmp >> 8) & 0xFF);
                 signalbyteData[j++] = (byte)(tmp & 0xFF);
                 signalbyteData[j++] = (byte)((tmp >> 8) & 0xFF);
             }
        
             float[] soundLo = new float[512];
            soundLo = fftFiltLow.doFFTFilter(soundpoints); 
             System.Array.Copy(soundLo, 0, soundLo, 0, soundpoints.Length);
             
             float[] soundHi = new float[soundpoints.Length];
             soundHi = fftFiltHi.doFFTFilter(soundpoints);
             System.Array.Copy(soundHi, 0, soundHi, 0, soundpoints.Length);

             float[] sounddiff = new float[soundpoints.Length];
             for (int i = 0; i < soundpoints.Length; i++)
             {
              
                 sounddiff[i] = (soundHi[i]) + (soundLo[i]);
                 //sounddiff[i] = (soundHi[i]) - (soundLo[i]);
             }

            // rttyDecode1.demodulate1(soundHi, soundLo);
            markTonepower = calcMag(soundHi,fftw);
            spaceTonepower = calcMag(soundLo,fftw);
            
             float power = 0; ;

            
             fftdisplay = fftw.getFFTMag(soundpoints);

             float[] findpeak = new float[fftdisplay.Length];
             for (int i = 0; i < fftdisplay.Length; i++)
             {
                 power = power + fftdisplay[i];
             }
             power = power / fftdisplay.Length; 
             
             

             if ((markTonepower>500000)||(spaceTonepower > 500000)){

                 for (int i = 0; i < soundpoints.Length; i++)
                 {
                     //soundpoints[i] = agc.doAGC(soundpoints[i]);

                 } 
            

             // if (power > 400000)
             
               //  rttyDecode1.demodulate(sounddiff);
                 rttyDecode1.demodulate1(soundHi, soundLo);
             }
             System.Array.Copy(fftdisplay, 0, findpeak, 0, findpeak.Length);
             fftdisplay = fftw.getFFTMag(soundpoints);
            if(track){
                if ((markTonepower > 500000) || (spaceTonepower > 500000))
             //if (power > 400000)//
             {
                 timecnt++;

                 if (timecnt == 10)
                 {
                     timecnt=0;
                     Array.Sort(findpeak);
                     int index = 0;
                     for (int i = 0; i < fftdisplay.Length; i++)
                     {
                         if (findpeak[512] == fftdisplay[i])
                         {
                             index = i;
                             break;
                         }
                     }
                   //  fftdisplay = fftw.getFFTMag(soundpoints);
                     float binf = (float) index * ((float)Config.samplingrate / (float)Config.FFTRES);
                     int bin = (int)Math.Round(binf);
                     if ((bin >= 1000) || (bin <= 3500)){
                     if ((bin < freqlo - 10) || (bin > freqhi + 10))
                     {
                         //for (int i = 0; i < fftdisplay.Length; i++)
                        // {
                        //     fftdisplay[i] = 200000000 * 4;
                        // }
                         //Out of lock
                         if ((bin > freqhi + 10)&&(bin < freqhi+1400))
                         {
                             
                            // freqhi = bin;
                           //  freqlo = bin - 500;
                             if(bin -freqhi > 50){
                                 //freqhi = freqhi + 50;
                                //freqlo = freqlo + 50;
                                 freqhi = bin;
                                 freqlo = bin - offset;

                             }else{
                                freqhi = freqhi+10;
                                freqlo = freqlo+10;
                             }
                             fftFiltLow.calcFilterFFTCoefficients(FFTfilter.BANDPASS, freqlo - 50, 100, 2);
                             fftFiltHi.calcFilterFFTCoefficients(FFTfilter.BANDPASS, freqhi - 50, 100, 2);
                             demod.changefreq(freqhi, freqlo);
                         }
                         else
                             //do filter hi and low -350hz.//Recalulate constants here. Cant adjust above 2300
                             if ((bin < freqlo - 10)&&(bin > freqlo-1400))
                             {
                                 //do filter lo and hi + 350hz.    Can adjust below 900.}
                                 //freqhi = bin + 500;
                                 //freqlo = bin;
                                 if (freqlo - bin > 50)
                                 {
                                     //freqhi = freqhi - 50;
                                     //freqlo = freqlo - 50;
                                     freqhi = bin + offset;
                                     freqlo = bin;
                                 }
                                 else
                                 {
                                     freqhi = freqhi - 10;
                                     freqlo = freqlo - 10;
                                 }
                                fftFiltLow.calcFilterFFTCoefficients(FFTfilter.BANDPASS, freqlo - 50, 100, 2);
                                fftFiltHi.calcFilterFFTCoefficients(FFTfilter.BANDPASS, freqhi - 50, 100, 2);
                                 demod.changefreq(freqhi, freqlo);

                             }
                     }
                 }

                 }
             }
         }
          //  fftdisplay = fftw.getFFTMag(sounddiff);
             if (fftdisplay != null)
             {
                 if (markTonepower > spaceTonepower) power = (float)markTonepower; else power = (float)spaceTonepower;
                 if (cnt == 1)//Slow down the display routine as the calculations take too much time.
                 {
                    
                  //  gp.setPlotValuesPolyGon(fftdisplay, pictureBox1,(freqlo+(freqhi-freqlo)/2));
                    gr.storePointstoPlot(fftdisplay,power,((float)(freqlo+((float)(freqhi-freqlo)/2))));
                    cnt = 0;
                 }
                 else
                 {
                     cnt++;
                 }
             }
         }

         public void updatefilterMark(int mousePTR)
         {
             
             int freqofmouseptr = (int)(mousePTR * 23.47 / 2) + 1000;
             freqhi = freqofmouseptr;
             freqlo = freqhi - offset;
             fftFiltLow.calcFilterFFTCoefficients(FFTfilter.BANDPASS, freqlo - 50, 100, 2);
             fftFiltHi.calcFilterFFTCoefficients(FFTfilter.BANDPASS, freqhi - 50, 100, 2);
             demod.changefreq(freqhi, freqlo);
         }
         public void updatefilterMarkfreq(int freq)
         {
             freqhi = freq;
             freqlo = freqhi - offset;
             fftFiltLow.calcFilterFFTCoefficients(FFTfilter.BANDPASS, freqlo - 50, 20, 2);
             fftFiltHi.calcFilterFFTCoefficients(FFTfilter.BANDPASS, freqhi - 50, 20, 2);
             demod.changefreq(freqhi, freqlo);
         }
         public void updateoffset(int offset)
         {
             this.offset = offset;
             bwoffset =  (int)((float)this.offset / ((float)Config.samplingrate / (float) Config.FFTRES));
             gr.filterBW(bwoffset);
         }
       
        private float[] ConvertToushortsoundin(byte[] signalbyteData,int channel)
        {
           
            /*Take initial sound buffer and convert it to float for further processing*/
            /*This also takes care of converting the little endian sound data*/
            /*It has been set up to assume 2 input e.g. stereo 16 bit */
            /*Data is interleaved start with left channel*/
            /*0 = Left Channel 1 = Right Channel*/
            
            float[] input = new float[(signalbyteData.Length / 4)];
            int numSamplesRead = 0;

            for (int i = channel*2; i < signalbyteData.Length; )
            {
                short x = (short)(signalbyteData[i++] & 0xff);
                x += (short)((signalbyteData[i++] & 0xff) << 8);
                input[numSamplesRead++] = (short)x/4;
                i += 2;                                           
            }
            return input;
        }
        
    public double calcMag(float[] datain,FFTW fftwtemp){
        float[] fftpowerCalc = new float[datain.Length];
        fftpowerCalc = fftwtemp.getFFTMag(datain);
        double power = 0.0;
      
        for (int i = 0; i < fftpowerCalc.Length; i++)
        {
            power = power + fftpowerCalc[i];
        }
        power = power / fftpowerCalc.Length;
        return power;
     }
    public void afcenabled(Boolean afc)
    {
        this.track = afc;
    }
    public void Halt()
    {
        close = true;
    }
    public void cont()
    {
        close = false;
    }
    public void Close()
    {
       
        
        close = true;
       // Thread.Sleep(100);
        fftw.FreeFFTW();
    }
  }

}
    
	