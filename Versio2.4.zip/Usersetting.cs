﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TNCAX25Emulator
{
   public static class Usersetting
    {
       
       public static string callsign{get;set;}
       public static string path { get; set; }
       public static string comport { get; set; }
       public static int soundcardindexOut { get; set; }
       public static int soundcardindexIn { get; set; }
       public static int APRSintervalindex { get; set; }
       public static Boolean kissenabled { get; set; }
       public static Boolean mapenabled { get; set; }
       public static Boolean soundEnabledCB { get; set; }
       public static Boolean soundEnabledCBIn { get; set; }
       public static string serverport { get; set; }
       public static int offset { get; set; }
       public static int baud { get; set; }
       public static int mark { get; set; }
       public static Boolean rttyenabled { get; set; }
       public static Boolean reverseenabled { get; set; }
       public static Boolean afcenabled { get; set; }
       public static Boolean logging { get; set; }
       public static Boolean weblogging { get; set; }
       public static string weblogurl { get; set; }
    }
}
