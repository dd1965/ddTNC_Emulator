﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TNCAX25Emulator
{
    class Agc
    {
        float iout,iout1 = 0;
        static int SPOINT=150;
        float err;
        float GAIN = (float) 0.0001;//was 0.0001

        public float doAGC(float yin)
        {
            float yout = 0;
            yout = yin * iout;

            /*Calculate error */
            err = SPOINT - Math.Abs(yout);
  
            iout1 = iout;
            iout = iout1 + GAIN * err;
            if ( iout > 1) return yin;
            return yout;
        }
    }
}
