﻿
//-----------------------------------------------------------------------
// <copyright file="MessageHandler" company="(none)">
//  Copyright (c) 2013 VK3TBC
//
//  Permission is hereby granted, free of charge, to any person obtaining
//  a copy of this software and associated documentation files (the
//  "Software"), to deal in the Software without restriction, including
//  without limitation the rights to use, copy, modify, merge, publish,
//  distribute, sublicense, and/or sell copies of the Software, and to
//  permit persons to whom the Software is furnished to do so, subject to
//  the following conditions:
//
//  The above copyright notice and this permission notice shall be
//  included in all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
//  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
//  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
//  ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
//  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//  SOFTWARE
// </copyright>
// <author>VK3TBC</author>
// Message handler expects to take a message off the queue starting with
// a $ and ending in CR or LF. A design decision has been made that the 
// that receives it must do some logic to detect a valid string start and 
// stop. Also, string length cannot exceed 255 characters 
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WinMM;
using System.Threading;
using System.Collections.Concurrent;

namespace TNCAX25Emulator
{
    class MessageHandler
    {
        Aprs aprs;
        Andyprotocol aprot;
        WaveOut waveOut;
        GenerateTone gt;
        Hdlc hdlc;
        Form1 form;
        Serial serialporthandlerTNC;
        Kiss kiss;
        byte[] rttyRXGPS;
        int bytecount = 0;
        private static ReaderWriterLockSlim _lock = new ReaderWriterLockSlim();
        byte[] receivedAPRSmessage;
        public static ConcurrentQueue<byte[]> receivequeue = new ConcurrentQueue<byte[]>();
        public MessageHandler(Form1 form,Aprs aprs,Andyprotocol aprot,Hdlc hdlc,Kiss kiss)
        {
            this.form = form; //Clunky but (KISS) needed to communicate to update screen. Tried many "standard"
                              //ways to get round this...., just wont work to extend events.
            this.aprs = aprs;
            this.aprot = aprot;
            this.kiss=kiss;
            this.hdlc = hdlc;
            rttyRXGPS = new byte[255];
            Thread thread = new Thread(new ThreadStart(do_workThread));
            thread.Name = "MessageHandlerQueue";
            thread.IsBackground = true;
            thread.Start();
        }
        public void setWaveOutRefandToneRef(WaveOut waveOut,GenerateTone gt)
        {
            this.waveOut = waveOut;
            this.gt = gt;
        }
        public void setSerialport(Serial serialporthandlerTNC)
        {
            this.serialporthandlerTNC = serialporthandlerTNC;
        }

        private void do_workThread()
        {
            while (true)
            {
                if (!receivequeue.IsEmpty)
                {
                    byte[] processRXdataarray;
                     receivequeue.TryDequeue(out processRXdataarray);
                     dowork(processRXdataarray);
                }
                Thread.Sleep(20);
            }

        }


        private void dowork(byte[] rxByte)
        {
            for (int i = 0; i < rxByte.Length; i++)
            {processReceivedRxByte(rxByte[i]);
            }
        }





        public void processReceivedRxByte(byte gpsByte)
        {
            byte[] gpsByteCh = new byte[1];
            gpsByteCh[0] = gpsByte;
            String TCPsrvrecv = ASCIIEncoding.ASCII.GetString(gpsByteCh);
            /*      if (bytecount == 51)
                  {
                      String test123 = "123";
                      bytecount = 0;
                  }*/
            form.SetTextRTTY(TCPsrvrecv);
            if (bytecount == 255) bytecount = 0;
            
            //  rttyRXGPS[bytecount++] = gpsByte;
            //  return;
            if (bytecount == 0)
            {
                if (gpsByte == 0x24)
                {
                    /* found $ which is the start of the string so store until /n is detected*/
                    /* keep a size of the byte count, if its > 255 bytes, likely it was corrupted*/
                    rttyRXGPS[0] = gpsByte;
                    bytecount = 1;
                }
            }
            else
            {
                // if(bytecount == 50)
                if ((gpsByte == 0x0A) || (gpsByte == 0x0D))
                {
                    int cnt = 0;

                    for (int i = 0; i < rttyRXGPS.Length; i++)
                    {
                        if (rttyRXGPS[i] == 0x24) cnt++;
                    }
                    byte[] newbuffertosendcorrectlength = new byte[bytecount - cnt];//was -1
                    Array.Copy(rttyRXGPS, cnt, newbuffertosendcorrectlength, 0, newbuffertosendcorrectlength.Length);//was 1


                    if (aprot.processRXrttystring(newbuffertosendcorrectlength) != null)
                    {
                        string value = ASCIIEncoding.ASCII.GetString(newbuffertosendcorrectlength);
                        if (Usersetting.logging) Logging.logData("$$"+value);
                        if (Usersetting.weblogging) WebLog.sendWebLog("$$" + value);
                        form.SetTextRTTYGood(value + " Valid CRC" + "\n");
                        byte[] array = aprs.constructAX25APRS(newbuffertosendcorrectlength, Usersetting.callsign, Usersetting.path, form.getTextbox3info());
                        if (array != null)
                        {
                            if (Usersetting.APRSintervalindex > 0)
                            {
                                _lock.EnterReadLock();
                                receivedAPRSmessage = new byte[array.Length];
                                Array.Copy(array, 0, receivedAPRSmessage, 0, array.Length);
                               _lock.ExitReadLock();
                               form.receivedMessage(receivedAPRSmessage);
                            }

                            if (Usersetting.kissenabled && Usersetting.APRSintervalindex == 0)
                            {
                                byte[] encodedkissbuffer = kiss.encodeKissFrame(array);
                                try
                                {
                                    (serialporthandlerTNC.getSerialPortRef()).Write(encodedkissbuffer, 0, encodedkissbuffer.Length); //Send data to Packet Engine Pro

                                }
                                catch (Exception e)
                                {
                                    // MessageBox.Show("Cannot write to serial port -> ", "TNCAX25Emulator",
                                    //  MessageBoxButtons.OK, MessageBoxIcon.Error);

                                }
                            }
                            if (Usersetting.soundEnabledCB && Usersetting.APRSintervalindex == 0)
                                if (waveOut != null)
                                    hdlc.senddata(array, gt);

                            form.updatereceivedfields();



                            // value = ASCIIEncoding.ASCII.GetString(encodedkissbuffer);
                            if (Usersetting.APRSintervalindex > 0)
                            {
                                value = "Queueing Msg " + " " + Usersetting.callsign + " via " + Usersetting.path + " " + TNCAX25Emulator.Receivedparameters.payload() + " " + form.getTextbox3info();
                                form.SetTextAPRS(value + "\n");
                            }
                            else
                            {
                                if (Usersetting.kissenabled)
                                {
                                    value = "Sending to TNC on " + serialporthandlerTNC.getthisPort() + " " + Usersetting.callsign + " via " + Usersetting.path + " " + TNCAX25Emulator.Receivedparameters.payload() + " " + form.getTextbox3info();
                                   form.SetTextAPRS(value + "\n");
                                }
                                if (Usersetting.soundEnabledCB)
                                {
                                    value = "Sending to Sound Card " + " " + Usersetting.callsign + " via " + Usersetting.path + " " + TNCAX25Emulator.Receivedparameters.payload() + " " + form.getTextbox3info();
                                    form.SetTextAPRS(value + "\n");
                                }
                            }

                        }
                        else
                        {
                            form.SetTextAPRS("Error in constructing APRS packet\n");
                        }
                    }

                    else
                    {
                        form.SetTextRTTY("Error in Frame" + "\n");
                    }
                    bytecount = 0;    //Hunt for start of GPS frame again.
                    Array.Clear(rttyRXGPS, 0, rttyRXGPS.Length);//was 127

                }
                else
                {
                    if (gpsByte == 0x24)
                    {
                        bytecount = 1;
                        rttyRXGPS[0] = gpsByte;
                        //Hunt for start of GPS frame again.
                        //Array.Clear(rttyRXGPS, 0, rttyRXGPS.Length);

                    }
                    else
                    {
                        rttyRXGPS[bytecount++] = gpsByte;
                    }
                }
            }

        }
    }
}
